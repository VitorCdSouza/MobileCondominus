using TelaLogin.ViewModels.Usuarios;

namespace TelaLogin.Views.Comunicacao;

public partial class AvisosView : ContentPage
{
    UsuarioViewModel usuarioViewModel;
    public AvisosView()
	{
		InitializeComponent();
        NavigationPage.SetHasNavigationBar(this, false);

        usuarioViewModel = new UsuarioViewModel();
        BindingContext = usuarioViewModel;
    }
}